package com.mindcare.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val entries = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(mood: Int, text: String) {
        viewModelScope.launch {
            dao.insert(Entry(timestamp = System.currentTimeMillis(), mood = mood, text = text.trim()))
        }
    }

    fun delete(e: Entry) {
        viewModelScope.launch { dao.delete(e) }
    }
}
