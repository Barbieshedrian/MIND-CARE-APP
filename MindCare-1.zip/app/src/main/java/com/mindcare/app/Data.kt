package com.mindcare.app

import android.content.Context
import android.util.Base64
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** One mood check-in / journal entry. Text may be empty for a quick check-in. */
@Entity(tableName = "entries")
data class Entry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val mood: Int,          // 1 (very low) .. 5 (great)
    val text: String
) {
    fun date(): LocalDate =
        Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDate()
}

@Dao
interface EntryDao {
    @Query("SELECT * FROM entries ORDER BY timestamp DESC")
    fun all(): Flow<List<Entry>>

    @Insert
    suspend fun insert(e: Entry)

    @Delete
    suspend fun delete(e: Entry)
}

@Database(entities = [Entry::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): EntryDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(context: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDb::class.java, "mindcare.db")
                .build().also { instance = it }
        }
    }
}

/** Local account + settings. The PIN is never stored, only a salted PBKDF2 hash. */
class Session(context: Context) {
    private val p = context.getSharedPreferences("mindcare_prefs", Context.MODE_PRIVATE)

    val hasAccount: Boolean get() = p.contains("hash")
    val name: String get() = p.getString("name", "") ?: ""

    var reminders: Boolean
        get() = p.getBoolean("reminders", false)
        set(v) { p.edit().putBoolean("reminders", v).apply() }

    fun register(name: String, email: String, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("name", name)
            .putString("email", email)
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .apply()
    }

    fun verify(pin: String): Boolean {
        val salt = Base64.decode(p.getString("salt", "") ?: "", Base64.NO_WRAP)
        val stored = Base64.decode(p.getString("hash", "") ?: "", Base64.NO_WRAP)
        return MessageDigest.isEqual(hash(pin, salt), stored)
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)).encoded
}

data class Mood(val emoji: String, val label: String)

val MOODS = listOf(
    Mood("😢", "Very low"), Mood("😕", "Low"), Mood("😐", "Okay"),
    Mood("🙂", "Good"), Mood("😄", "Great")
)

data class Hotline(val name: String, val number: String)

val HOTLINES = listOf(
    Hotline("CBT Kenya", "+254739935333"),
    Hotline("CBT Kenya (alt)", "+254756454585"),
    Hotline("Befrienders Kenya", "+254722178177")
)

val TIPS = listOf(
    "Anxiety often eases when you slow your breathing. Try inhaling for 4 seconds, holding for 4, and exhaling for 4.",
    "Naming a feeling out loud or in writing can reduce its intensity. What are you feeling right now?",
    "Regular sleep and wake times are one of the strongest protectors of mood.",
    "A 10-minute walk can lift mood for a couple of hours. Small steps count.",
    "Depression can make everything feel harder. Doing one tiny task is a real win.",
    "Grief has no timeline. It comes in waves, and you don't have to 'get over it'.",
    "Talking to someone you trust is a sign of strength, not weakness.",
    "Try 5-4-3-2-1 grounding: name 5 things you see, 4 you feel, 3 you hear, 2 you smell, 1 you taste.",
    "Social media comparison can quietly lower mood. Notice how you feel after scrolling.",
    "Mood swings that are intense or last for days deserve a check-up with a clinician.",
    "Gratitude journaling: write down three small good things from today.",
    "Caffeine and alcohol can both worsen anxiety and sleep.",
    "You can't pour from an empty cup. Rest is productive.",
    "Stress builds up when we skip breaks. Take a short pause every hour you study or work."
)

fun todaysTip(): String = TIPS[(LocalDate.now().toEpochDay() % TIPS.size).toInt()]

/** Number of consecutive days (ending today or yesterday) with at least one entry. */
fun streak(entries: List<Entry>): Int {
    val days = entries.map { it.date() }.toSet()
    var d = LocalDate.now()
    if (d !in days) d = d.minusDays(1)
    var n = 0
    while (d in days) { n++; d = d.minusDays(1) }
    return n
}
