package com.mindcare.app

data class ChatMsg(val text: String, val fromUser: Boolean, val crisis: Boolean = false)

/**
 * A simple, offline, rule-based supportive companion using basic CBT-style techniques.
 * It is NOT a therapist. Crisis language always triggers the hotline message first.
 * The reply() function is the single place to plug in a real language-model API later.
 */
object MindBuddy {
    const val WELCOME = "Hi, I'm MindBuddy, a supportive companion. I'm not a therapist and can't diagnose, " +
        "but I'm happy to listen and share some coping ideas. How are you feeling today?"

    private val crisisWords = listOf(
        "suicid", "kill myself", "end my life", "want to die", "wanna die", "hurt myself",
        "self harm", "self-harm", "cut myself", "no reason to live", "better off dead", "end it all"
    )

    private val anxious = listOf("anxi", "panic", "worry", "worried", "nervous", "afraid", "scared")
    private val low = listOf("sad", "depress", "hopeless", "empty", "worthless", "cry", "not good", "not okay", "not ok", "bad day")
    private val stress = listOf("stress", "overwhelm", "pressure", "exam", "deadline", "burnout", "too much")
    private val sleep = listOf("sleep", "insomnia", "can't sleep", "tired", "exhausted")
    private val grief = listOf("grief", "died", "death", "passed away", "miss him", "miss her", "funeral")
    private val lonely = listOf("lonely", "alone", "isolated", "no friends")
    private val angry = listOf("angry", "anger", "furious", "rage", "irritated")
    private val bipolar = listOf("manic", "mania", "bipolar", "mood swing", "hypomanic")
    private val happy = listOf("happy", "good", "great", "better", "grateful", "excited", "proud")

    private val prompts = listOf(
        "Thank you for sharing that. What do you think is behind the feeling?",
        "That sounds like a lot. What has been the hardest part of today?",
        "I'm listening. Is there something small that would make the rest of today a little easier?",
        "How long have you been feeling this way?",
        "If a friend told you this, what would you say to them?"
    )

    fun isCrisis(text: String): Boolean {
        val s = text.lowercase()
        return crisisWords.any { it in s }
    }

    private fun has(s: String, words: List<String>) = words.any { it in s }

    fun reply(input: String): ChatMsg {
        val s = input.lowercase()

        if (isCrisis(s)) {
            return ChatMsg(
                "I'm really sorry you're in this much pain, and I'm glad you told me. You matter, and you " +
                    "don't have to carry this alone. Please reach out to a real person right now. The people " +
                    "below are trained to listen. If you are in immediate danger, call your local emergency " +
                    "number or go to the nearest hospital.",
                fromUser = false, crisis = true
            )
        }

        val text = when {
            has(s, bipolar) ->
                "Big shifts in mood, energy or sleep are best looked at with a doctor or mental health professional. " +
                    "In the meantime, logging your mood and sleep daily in this app can give them useful information."
            has(s, grief) ->
                "I'm so sorry for your loss. Grief comes in waves and there's no right way to feel. " +
                    "Would you like to write about the person in your journal? Talking with someone you trust can also help."
            has(s, anxious) ->
                "Anxiety is really uncomfortable. Try box breathing: breathe in for 4, hold for 4, out for 4, hold for 4, " +
                    "and repeat 4 times. You can also try 5-4-3-2-1 grounding: name 5 things you can see, 4 you can feel, " +
                    "3 you can hear, 2 you can smell and 1 you can taste. What's been worrying you?"
            has(s, stress) ->
                "It sounds like you're carrying a lot. Try writing down everything on your mind, then pick just one " +
                    "small task to do next. Short breaks help too. What feels most urgent right now?"
            has(s, sleep) ->
                "Poor sleep affects mood a lot. Try a fixed bedtime, no screens for 30 minutes before bed, and less caffeine " +
                    "in the afternoon. If sleep problems continue for weeks, please see a health professional."
            has(s, lonely) ->
                "Feeling alone hurts. Is there one person you could send a short message to today? " +
                    "Even a small connection can help."
            has(s, angry) ->
                "Anger is a valid feeling. Give yourself a pause: step away, take slow breaths, or go for a short walk " +
                    "before responding. What happened?"
            has(s, low) ->
                "I'm sorry you're feeling this way. When mood is low, tiny steps help: drink some water, get some daylight, " +
                    "or message someone you trust. If this has lasted more than two weeks, please consider speaking to a " +
                    "professional. Would you like to tell me more?"
            has(s, happy) ->
                "That's lovely to hear! What's contributing to it? Writing it in your journal can help you remember " +
                    "what works for you."
            else -> prompts[(s.length + s.count { it == ' ' }) % prompts.size]
        }
        return ChatMsg(text, fromUser = false)
    }
}
