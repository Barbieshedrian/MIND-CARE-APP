package com.mindcare.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ---------------------------------------------------------------- shell

@Composable
fun MainScreen(vm: MainViewModel, session: Session, onLock: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val tabs = listOf(
        "Home" to Icons.Default.Home,
        "Journal" to Icons.Default.Edit,
        "Chat" to Icons.Default.Chat,
        "Trends" to Icons.Default.ShowChart,
        "Support" to Icons.Default.Favorite
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm, session)
                1 -> JournalScreen(vm)
                2 -> ChatScreen()
                3 -> TrendsScreen(vm)
                else -> SupportScreen(session, onLock)
            }
        }
    }
}

// ---------------------------------------------------------------- shared bits

@Composable
fun MoodPicker(selected: Int?, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        MOODS.forEachIndexed { i, m ->
            val on = selected == i + 1
            Column(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .background(if (on) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .clickable { onSelect(i + 1) }
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(m.emoji, fontSize = 30.sp)
                Text(m.label, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun HotlineButtons() {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HOTLINES.forEach { h ->
            Button(
                onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${h.number}"))) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Call, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("${h.name}: ${h.number}")
            }
        }
    }
}

// ---------------------------------------------------------------- home

@Composable
fun HomeScreen(vm: MainViewModel, session: Session) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val today = entries.firstOrNull { it.date() == LocalDate.now() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Hello, ${session.name} 👋", style = MaterialTheme.typography.headlineSmall)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("How are you feeling right now?", style = MaterialTheme.typography.titleMedium)
                MoodPicker(selected = today?.mood) { vm.add(it, "") }
                if (today != null) Text("✓ Checked in today", color = MaterialTheme.colorScheme.primary)
            }
        }

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("💡 Daily insight", style = MaterialTheme.typography.titleMedium)
                Text(todaysTip(), style = MaterialTheme.typography.bodyLarge)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("🔥 ${streak(entries)}-day check-in streak", style = MaterialTheme.typography.titleMedium)
                Text("${entries.size} entries in total", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

// ---------------------------------------------------------------- journal

private val dateFmt = DateTimeFormatter.ofPattern("EEE, d MMM yyyy · HH:mm")

@Composable
fun JournalScreen(vm: MainViewModel) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (entries.isEmpty()) item {
                Text("No entries yet. Tap + to write your first one.", style = MaterialTheme.typography.bodyLarge)
            }
            items(entries, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(MOODS[e.mood - 1].emoji, fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(MOODS[e.mood - 1].label, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    Instant.ofEpochMilli(e.timestamp).atZone(ZoneId.systemDefault()).format(dateFmt),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            IconButton(onClick = { vm.delete(e) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete entry")
                            }
                        }
                        if (e.text.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(e.text, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { adding = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "New entry") }
    }

    if (adding) {
        var mood by remember { mutableIntStateOf(3) }
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New journal entry") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    MoodPicker(mood) { mood = it }
                    OutlinedTextField(
                        text, { text = it }, label = { Text("What's on your mind?") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.add(mood, text); adding = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- chat

@Composable
fun ChatScreen() {
    val msgs = remember { mutableStateListOf(ChatMsg(MindBuddy.WELCOME, false)) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size) { listState.animateScrollToItem(msgs.lastIndex) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty()) return
        msgs.add(ChatMsg(t, true))
        msgs.add(MindBuddy.reply(t))
        input = ""
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState, modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(msgs) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = when {
                            m.crisis -> MaterialTheme.colorScheme.errorContainer
                            m.fromUser -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(m.text)
                            if (m.crisis) HotlineButtons()
                        }
                    }
                }
            }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type how you're feeling…") }, maxLines = 4
            )
            IconButton(onClick = { send() }) { Icon(Icons.Default.Send, contentDescription = "Send") }
        }
    }
}

// ---------------------------------------------------------------- trends

@Composable
fun TrendsScreen(vm: MainViewModel) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val avgs: List<Float?> = (13 downTo 0).map { back ->
        val day = today.minusDays(back.toLong())
        val moods = entries.filter { it.date() == day }.map { it.mood }
        if (moods.isEmpty()) null else moods.average().toFloat()
    }
    val logged = avgs.filterNotNull()
    val primary = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Your last 14 days", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("😄 great", style = MaterialTheme.typography.labelSmall)
                    Text("😢 very low", style = MaterialTheme.typography.labelSmall)
                }
                Canvas(Modifier.fillMaxWidth().height(200.dp)) {
                    val pad = 16f
                    val w = size.width - 2 * pad
                    val h = size.height - 2 * pad
                    for (m in 1..5) {
                        val y = pad + h - (m - 1) / 4f * h
                        drawLine(grid, Offset(pad, y), Offset(pad + w, y), 2f)
                    }
                    val pts = avgs.mapIndexedNotNull { i, v ->
                        v?.let { Offset(pad + i / 13f * w, pad + h - (it - 1) / 4f * h) }
                    }
                    for (k in 0 until pts.size - 1) drawLine(primary, pts[k], pts[k + 1], 6f)
                    pts.forEach { drawCircle(primary, 10f, it) }
                }
                Text("Oldest → today", style = MaterialTheme.typography.labelSmall)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (logged.isEmpty()) {
                    Text("Log a few check-ins and your trend will appear here.")
                } else {
                    val avg = logged.average()
                    Text("Average mood: ${"%.1f".format(avg)} / 5  ${MOODS[avg.toInt().coerceIn(1, 5) - 1].emoji}",
                        style = MaterialTheme.typography.titleMedium)
                    Text("Days logged: ${logged.size} of 14")
                    Text("Current streak: ${streak(entries)} days")
                }
            }
        }
    }
}

// ---------------------------------------------------------------- support & settings

@Composable
fun SupportScreen(session: Session, onLock: () -> Unit) {
    val context = LocalContext.current
    var reminders by remember { mutableStateOf(session.reminders) }

    fun enable() { session.reminders = true; Reminder.schedule(context); reminders = true }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) enable()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("🆘 Need to talk to someone now?", style = MaterialTheme.typography.titleMedium)
                Text("If you are thinking about harming yourself, please call one of these lines. " +
                    "If you are in immediate danger, call your local emergency number or go to the nearest hospital.")
                HotlineButtons()
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Settings", style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Daily reminder")
                        Text("A gentle nudge at 8:00 PM", style = MaterialTheme.typography.labelSmall)
                    }
                    Switch(checked = reminders, onCheckedChange = { on ->
                        if (!on) {
                            session.reminders = false; Reminder.cancel(context); reminders = false
                        } else if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) {
                            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else enable()
                    })
                }
                OutlinedButton(onClick = onLock, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Lock, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Lock app")
                }
            }
        }

        Text(
            "Mind Care is a self-care and awareness tool. It is not a substitute for professional " +
                "mental health care. Your entries are stored only on this device.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
