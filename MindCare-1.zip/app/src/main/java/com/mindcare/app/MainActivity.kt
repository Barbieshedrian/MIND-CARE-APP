package com.mindcare.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)
        setContent { MindCareTheme { AppRoot() } }
    }
}

@Composable
fun MindCareTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF3F7D6E),
            primaryContainer = Color(0xFFD7EBE5),
            onPrimaryContainer = Color(0xFF12332B),
            background = Color(0xFFF7FAF9),
            surface = Color(0xFFF7FAF9),
            surfaceVariant = Color(0xFFE8F0ED),
            errorContainer = Color(0xFFFCE4E4)
        ),
        content = content
    )
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val session = remember { Session(context) }
    var unlocked by remember { mutableStateOf(false) }

    if (!unlocked) AuthScreen(session) { unlocked = true }
    else MainScreen(vm, session) { unlocked = false }
}

@Composable
fun AuthScreen(session: Session, onDone: () -> Unit) {
    val registering = !session.hasAccount
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val pinOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(48.dp))
        Text("🌿 Mind Care", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Text(
            if (registering) "Create your private space. Everything stays on this device."
            else "Welcome back. Enter your PIN to unlock.",
            style = MaterialTheme.typography.bodyLarge
        )
        if (registering) {
            OutlinedTextField(name, { name = it }, label = { Text("First name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(
            pin, { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
            label = { Text(if (registering) "Choose a PIN (4-6 digits)" else "PIN") },
            singleLine = true, keyboardOptions = pinOptions,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        if (registering) {
            OutlinedTextField(
                pin2, { if (it.length <= 6 && it.all(Char::isDigit)) pin2 = it },
                label = { Text("Confirm PIN") }, singleLine = true, keyboardOptions = pinOptions,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                if (registering) {
                    error = when {
                        name.isBlank() -> "Please enter your name."
                        !email.contains("@") -> "Please enter a valid email."
                        pin.length < 4 -> "PIN must be at least 4 digits."
                        pin != pin2 -> "PINs do not match."
                        else -> null
                    }
                    if (error == null) { session.register(name.trim(), email.trim(), pin); onDone() }
                } else {
                    if (session.verify(pin)) onDone() else { error = "Incorrect PIN."; pin = "" }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (registering) "Create account" else "Unlock") }
    }
}
